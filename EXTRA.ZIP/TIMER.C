/*
Demonstration of how to use the timer to generate events in the XView-PC GUI
By Antonio Carlos M. de Queiroz
Version 1.0 - 03/03/95
*/

#include <string.h>
#include <stdlib.h>
#include <dos.h>
#include <stdio.h>
#include "xview.h"

#ifdef __GNUC__
  #include <go32.h>
  #include <dpmi.h>
  #include <values.h>
  _go32_dpmi_registers regs;
  _go32_dpmi_seginfo old_handler,new_handler;
  #define random(xxx) (int)(((long)rand()*xxx)/(RAND_MAX+1))
#else
  #ifdef __cplusplus
    #define __CPPARGS ...
  #else
    #define __CPPARGS
  #endif
  void interrupt (*ptemp)(__CPPARGS);
#endif

Xv_opaque frame1,tty1,canvas1,button2,button1;
short int connected;

#ifdef __GNUC__
void Interruptor(_go32_dpmi_registers *r)
#else
void interrupt Interruptor(__CPPARGS)
#endif
{
  /*
     When the "xv_main_loop" routine is waiting for an event, "ie_code"=-1.
     If this value is changed, an event is generated, and can be processed
     normally by the event handler of the object under the "mouse" cursor.
     All that is necessary to do is to install this routine in the clock
     tick interrupt (0x1C), and process the event "5000" with normal event
     handlers.
  */
  if (ie_code==-1) ie_code=5000;
  #ifdef __GNUC__
  /* What is the function? */
  #else
  ptemp(__CPPARGS);
  #endif
}

void e_draw(Xv_opaque obj)
{
  char txt[2];
  int xx,yy,bb;
  /* Event handler for canvas1 and tty1*/
  if (ie_code==5000) {
    bb=random(15);
    setcolor(bb);
    xx=random(canvas1->dx);
    yy=random(canvas1->dy);
    circle(xx,yy,random(100));
  }
  else if (ie_code<256) {
    if (ie_code==13) ttysw_output(tty1,"\r\n");
    else {
      txt[0]=(char)ie_code;
      txt[1]='\0';
      ttysw_output(tty1,txt);
    }
  }
}

void n_start(Xv_opaque obj)
{
  /* Notify handler for button1 */
  /* Connects the interrupt handler to the clock tick*/
  if (!connected) {
    #ifdef __GNUC__
    _go32_dpmi_get_real_mode_interrupt_vector(0x1C,&old_handler);
    new_handler.pm_offset=Interruptor;
    _go32_dpmi_allocate_real_mode_callback_iret(&new_handler,&regs);
    _go32_dpmi_set_real_mode_interrupt_vector(0x1C,&new_handler);
    #else
    ptemp=getvect(0X1C);
    setvect(0X1C,Interruptor);
    #endif
    connected=1;
    ttysw_output(tty1,"[Connected]");
  }
}

void n_stop(Xv_opaque obj)
{
  /* Notify handler for button2 */
  /* Disconnects the interrupt handler */
  if (connected) {
    #ifdef __GNUC__
    _go32_dpmi_set_real_mode_interrupt_vector(0x1C,&old_handler);
    _go32_dpmi_free_real_mode_callback(&new_handler);
    #else
    setvect(0X1C,ptemp);
    #endif
    connected=0;
    ttysw_output(tty1,"[Disconnected]");
  }
}

void main()
{
  /* Inicialization */
  connected=0;
  xv_init(0,0);
  /* Interface objects creation */
  frame1=xv_create(frame);
    strcpy(frame1->xv_label,"Events created by timer");
    frame1->dx=300;
    frame1->dy=300;
    frame1->x=(getmaxx()-frame1->dx)/2;
    frame1->y=(getmaxy()-frame1->dy)/2;
  tty1=xv_create(tty);
    tty1->y=16;
    tty1->v.stty.tty_yext=0; tty1->dy=73;
    tty1->event_handler=(xv_handler)e_draw;
  canvas1=xv_create(canvas);
    canvas1->y=95;
    canvas1->event_handler=(xv_handler)e_draw;
  button2=xv_create(button);
    strcpy(button2->xv_label,"Stop");
    button2->x=49;
    button2->notify_handler=(xv_handler)n_stop;
  button1=xv_create(button);
    strcpy(button1->xv_label,"Start");
    button1->notify_handler=(xv_handler)n_start;
  ttysw_output(tty1,"Write here: ");
  xv_main_loop(frame1);
  /* Exit */
  restorecrtmode();
}
