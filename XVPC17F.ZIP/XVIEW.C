#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <dos.h>
#ifdef __GNUC__
#include <std.h>
#include <gppconio.h>
#include <libbcc.h>
#include <pc.h>
#else
#include <alloc.h>
#include <graphics.h>
#include <conio.h>
#endif
#include "mickey.h"
#include "xview.h"

/*
 *  XView-PC graphical user interface. Turbo C version.
 *  By Antonio Carlos Moreirao de Queiroz - acmq@coe.ufrj.br
 *  Version 1.0 - 05/07/92
 *  Version 1.6 - As version 1.6 in Pascal
 *  Version 1.6a - C++ compatible, extended keyboard event codes
 *  bugs corrected: esc in textfield edition in overwrite mode corrected
 *                  mouse is now on after menu_show
 *                  event handler call after menu selection safer
 *                  no extra line feed in tty
 *  interposer added, textfield editor changed, no more need of word align
 *  Version 1.6b - The same object files are compatible with C or C++
 *  The files xview.c and mickey.c must be compiled in C, not C++
 *  Version 1.7 - Compiles also under GNU C (djgpp).
 *  bug corrected: used events do not cause call (unsafe) to event handler.
 */

/* public global variables */
int wallpaper=0;               /* retain original background */
unsigned int normal_bsize=1000;/* attributed to "bsize" by "xv_create" */
unsigned int normal_length=20; /* attributed to "value_length" by "xv_create" */
int c_normal=   LIGHTGRAY;     /* object background color */
int c_active=   GREEN;         /* pressed buttons color */
int c_light=    15; /*WHITE*/  /* lighted corners color */
int c_shadow=   0;  /*BLACK*/  /* dark corners color */
int c_white=    15;            /* default "back_color" */
int c_black=    0;             /* default "fore_color" */
int c_overwrite=LIGHTRED;      /* overwrite color in textfields */
int c_edit=     BLUE;          /* edit color in textfields */
int c_insert=   YELLOW;        /* insert color in textfields */
int c_hatch=    CYAN;          /* background pattern color */
int type_hatch= XHATCH_FILL;   /* background pattern type */
int use_palette=1;             /* if bitmap palettes are used */
void *normal_client_data=NULL; /* attributed to "client_data" by "xv_create" */
int        nlines=60;          /* number of lines per image block */
int        insert;             /* if textfields are in insertion mode */
int        xv_ok;              /* result of the last window operation */
int        xv_end;             /* 1 terminates "xv_main_loop" */
xv_label_type ulttxt;          /* last text read in textfields */
int        ie_locx,ie_locy;    /* mouse position relative to object */
int        ie_code;            /* event code */
int        ie_shiftcode;       /* mouse buttons state */
Xv_opaque  active_w;           /* the active window frame */
Xv_opaque  active_o;           /* the active object */
Xv_opaque  w_base;             /* base window for "xv_create" */
Xv_opaque  o_base;             /* base object for "item_create" */
int redrawing_frame;           /* if a window is being redrawn */
void (*interposer)(void);      /* routine called after each event */

/* Private global variables */
static int m_pages=-1;             /* number of screens listed in tty objects in a call to "ttysw_output". -1=no limit */
static char gray50[8]={0xAA,0x55,0xAA,0x55,0xAA,0x55,0xAA,0x55}; /* gray pattern used in monochrome modes */
static Xv_opaque base_menu=NULL;   /* first menu in a series */
static int to_save;                /* if a window shall remember the background image */
static Xv_opaque active_menu;      /* activated menu in a series */
static ptrfig Pmove,Ptemp;         /* image pointers */

#ifdef __TURBOC__
long int maxavail(void)
/* Returns the largest free block in the heap */
{
  long int mem;
  struct heapinfo hi;
  assert(heapcheck()!=_HEAPCORRUPT); /* verifies heap integrity */
  mem=coreleft();
  hi.ptr=NULL;
  while (heapwalk(&hi)==_HEAPOK)
    if ((!hi.in_use) && hi.size>mem) mem=hi.size;
  return (mem);
}
#endif

/*
The next 6 routines are for manipulation of large images. Screen areas
are split in "nlines" lines blocks and saved in "figstruct" structures
*/

#ifdef __TURBOC__
long int figuresize(int x1,int y1,int x2,int y2)
{
  long int s;
  int nb;

  /*
  Considers that more 4 bytes are allocated for each item and
  that the number of bytes in each allocation is a multiple of 16
  */
  nb=(y2-y1)/nlines;
  s=(long)(3*sizeof(int)+((nb+1)*sizeof(void*)+20)&(~(unsigned)15));
  s=s+(long)nb*(long)((imagesize(x1,y1,x2,y1+nlines-1)+20)&(~(unsigned)15));
  s=s+(long)((imagesize(x1,y1,x2,y1+(y2-y1)%nlines)+20)&(~(unsigned)15));
  return(s);
}
#endif

void freefiguremem(ptrfig p)
{
  int i;
  for (i=p->blocks; i>=0; i--) if (p->v[i]) free(p->v[i]);
  free(p);
}

ptrfig getfiguremem(int dw, int dh)
{
  int i,nb;
  ptrfig p;

  nb=dh/nlines;
  p=(ptrfig)calloc(1,5*sizeof(int)+sizeof(void*)*(nb+1));
  if (!p) return NULL;
  p->blocks=nb;
  p->blocksize=imagesize(0,1,dw,nlines);
  p->fdx=dw;
  p->fdy=dh;
  for (i=0; i<nb; i++)
    if (!(p->v[i]=malloc(p->blocksize))) goto no_space;
  p->lastblocksize=imagesize(0,0,dw,dh%nlines);
  if ((p->v[nb]=malloc(p->lastblocksize))!=0) return p;
  no_space: {
    freefiguremem(p);
    return NULL;
  }
}

void getfigure(int x1,int y1, int x2,int y2,ptrfig p)
{
  int i,v1,v2;

  v1=y1; v2=y1+nlines-1;
  for (i=0; i<=p->blocks; i++) {
    if (v2>y2) v2=y2;
    getimage(x1,v1,x2,v2,p->v[i]);
    v1=v2+1; v2=v1+nlines-1;
  }
}

void putfigure(int x,int y, ptrfig p, unsigned int bitblt)
{
  int i,v;

  v=y;
  for (i=0; i<=p->blocks; i++) {
    putimage(x,v,p->v[i],bitblt);
    v+=nlines;
  }
}

#ifdef __TURBOC__
void movefigure(ptrfig p1,ptrfig p2)
/* Copies an image in memory. Used to reduce heap fragmentation */
/* Does not work with djgpp ? */
{
  int i;

  for (i=0; i<p1->blocks; i++) memmove(p2->v[i],p1->v[i],p1->blocksize);
  i=p1->blocks;
  memmove(p2->v[i],p1->v[i],p1->lastblocksize);
}
#endif

void drawbitmap(int x,int y,int *dw, int *dh, ptrfig *Pimg, const char *filename)
/* Reads and plots a Windows 16 colors bitmap */
{
  int i,j,k,b;
  FILE *arquivo;
  char *barra="/";
  char path[256];
  char *env;
  short int buf[166];

  typedef struct {unsigned short int w,h;} dimensions;

  if (*Pimg==NULL) {
    env=getenv("BMP");
    if (env) {
      strcpy(path,env);
      strcat(path,barra);
      strcat(path,filename);
    }
    else strcpy(path,filename);
    arquivo=fopen(path,"rb");
    if (arquivo) {
      fread(&buf,2,59,arquivo);
      *dw=buf[9]-1;
      *dh=buf[11]-1;
      if (use_palette) {
	for (i=0; i<=15; i++) {
	  k=27+2*i;
	  setrgbpalette(i,buf[k+1]>>2,buf[k]>>10,buf[k]>>2);
	  setpalette(i,i);
	}
      }
      k=*dw+1;
      while ((k % 8)!=0) k++;
      k=k/4;
      for (j=y+*dh; j>=y; j--) {
	fread(&buf,2,k,arquivo);
	swab((char*)buf,(char*)buf,k<<1);
	b=12;
	for (i=0; i<=*dw; i++) {
	  putpixel(x+i,j,(buf[i>>2]>>b)&(unsigned short int)15);
	  if (b>0) b-=4; else b=12;
	}
      }
      fclose(arquivo);
      if (((*Pimg)=getfiguremem(*dw,*dh))!=0) getfigure(x,y,x+*dw,y+*dh,*Pimg);
    }
  }
  else {
    putfigure(x,y,*Pimg,COPY_PUT);
    *dw=(*Pimg)->fdx;
    *dh=(*Pimg)->fdy;
  }
}

void nothing(Xv_opaque obj) /* Default callback */
{
}

void nointerpose(void) /* Default interposer */
{
}

/* Some procedures for internal use */

void impossible(void)
{
  sound(1000); delay(10); nosound(); xv_ok=0;
}

void set_fill(int cor)
{
  if (getmaxcolor()==1) setfillpattern(gray50,cor);
  else setfillstyle(SOLID_FILL,cor);
}

void square(int x,int y,int dx,int dy,int pressed, int fill)
{
  int xmrel,ymrel,c_canto1,c_canto2,c_fundo;

  if (pressed) {
    c_canto1=c_shadow;
    c_canto2=c_light;
    c_fundo=c_active;
  }
  else {
    c_canto1=c_light;
    c_canto2=c_shadow;
    c_fundo=c_normal;
  }
  xmrel=x+dx; ymrel=y+dy;
  if (fill) {
    set_fill(c_fundo);
    bar(x+1,y+1,xmrel-1,ymrel-1);
  }
  moveto(x,ymrel);
  setcolor(c_canto1);
  lineto(x,y); lineto(xmrel,y);
  setcolor(c_canto2);
  lineto(xmrel,ymrel); lineto(x,ymrel);
}

void direct_output(void)
{
  struct viewporttype *with1=&active_w->v.sframe.gr_out;
  setviewport(with1->left,with1->top,with1->right,with1->bottom,with1->clip);
}
 
void size_adjust(int *xx,int *yy,int *dxx,int *dyy,int dxmin,int dymin)
{
  if (*dxx<dxmin) *dxx=dxmin;
  else if (*dxx>getmaxx()) *dxx=getmaxx();
  if (*dyy<dymin) *dyy=dymin;
  else if (*dyy>getmaxy()) *dyy=getmaxy();
  if (*xx<0) *xx=0;
  else if (*xx+*dxx>getmaxx()) *xx=getmaxx()-*dxx;
  if (*yy<0) *yy=0;
  else if (*yy+*dyy>getmaxy()) *yy=getmaxy()-*dyy;
}

void total_view(void)
{
  setviewport(0,0,getmaxx(),getmaxy(),0);
}

void window_view(Xv_opaque w)
{
  setviewport(w->x+mrgx,w->y+mrgy,w->x+w->dx-mrgx,w->y+w->dy-mrgx,1);
}

void callback(xv_handler proc,Xv_opaque obj) /* Callback interface */
{
  struct viewporttype VPnormal;
  if (proc==(xv_handler)nothing) return;
  getviewsettings(&VPnormal);
  if (active_w) direct_output();
  cursor_off();
  (*proc)(obj);
  setviewport(VPnormal.left,VPnormal.top,VPnormal.right,VPnormal.bottom,VPnormal.clip);
  settextstyle(DEFAULT_FONT,HORIZ_DIR,1);
  settextjustify(LEFT_TEXT,TOP_TEXT);
  setlinestyle(SOLID_LINE,0,NORM_WIDTH);
  setwritemode(COPY_PUT);
}

/* Routines used with tty objects */

void inclim(unsigned int *x,unsigned int limite)
{
  if (*x<limite) *x+=1;
  else *x=0;
}

void declim(unsigned int *x,unsigned int limite)
{
  if (x>0) *x-=1;
  else *x=limite;
}

unsigned int sumlim(unsigned int x, unsigned int y, unsigned int limite)
{
  return((x+y+limite+1l) % (limite+1l));
}

void tty_clear(Xv_opaque t, int *pages)
{
  t->v.stty.xc=3;
  t->v.stty.yc=0;
  bar3d(t->x,t->y,t->x+t->v.stty.dxtty,t->y+t->dy,0,0);
  t->v.stty.tstart=t->v.stty.bcsr;
  *pages+=1;
}

void ttysw_output(Xv_opaque terminal,const char *texto)
{
  unsigned int k;
  char c;
  int i,pages,s_height,s_top;
  static char temp[2]="1";

  pages=0;
  if (terminal->owner!=active_w) open_window(terminal->owner);
  if (terminal->owner==active_w) {
    window_view(active_w);
    setfillstyle(SOLID_FILL,terminal->back_color);
    setcolor(terminal->fore_color);
    /* If the cursor is not in the screen, start the text from the new text */
    if (m_pages==-1 && terminal->v.stty.bcsr!=terminal->v.stty.tend)
       terminal->v.stty.bcsr=terminal->v.stty.tend;
    i=1;
    /* Adds new text to buffer */
    while (texto[i-1]) {
      terminal->v.stty.Pb[terminal->v.stty.tend]=texto[i-1];
      inclim(&terminal->v.stty.tend,terminal->v.stty.bsize);
      if (terminal->v.stty.tend == terminal->v.stty.bstart) {
	if (terminal->v.stty.bstart == terminal->v.stty.tstart) inclim(&terminal->v.stty.tstart,terminal->v.stty.bsize);
	if (terminal->v.stty.bcsr == terminal->v.stty.bstart) inclim(&terminal->v.stty.bcsr,terminal->v.stty.bsize);
	inclim(&terminal->v.stty.bstart,terminal->v.stty.bsize);
      }
      i++;
    }
    /* Draws text */
    if (terminal->v.stty.bcsr == terminal->v.stty.tend) tty_clear(terminal,&pages);
    else {
      settextstyle(SMALL_FONT,HORIZ_DIR,4); /* Here the tty font is set */
      while (terminal->v.stty.bcsr!=terminal->v.stty.tend) {
	c=terminal->v.stty.Pb[terminal->v.stty.bcsr];
	if (terminal->v.stty.xc+7>terminal->v.stty.dxtty && c!='\r'){
	  terminal->v.stty.xc=3;
	  terminal->v.stty.yc+=8;
	}
	if (terminal->v.stty.yc+12>terminal->dy)
	  if (pages==m_pages) goto get_out; else tty_clear(terminal,&pages);
	switch (c) {
	  case '\r': terminal->v.stty.xc=3;
	    break;
	  case '\n': terminal->v.stty.yc+=8;
	    break;
	  default: {
	    moveto(terminal->x+terminal->v.stty.xc,terminal->y+terminal->v.stty.yc);
	    temp[0]=c;
	    outtext(temp); terminal->v.stty.xc=getx()-terminal->x;
	  }
	}
	inclim(&terminal->v.stty.bcsr,terminal->v.stty.bsize);
      }
    }
   get_out:;
    settextstyle(DEFAULT_FONT,HORIZ_DIR,1); /* Restores normal font */
    /* Updates scrollbar */
    set_fill(c_active);
    i=terminal->dy-20; k=sumlim(terminal->v.stty.tend,-terminal->v.stty.bstart,terminal->v.stty.bsize);
    if (k) {
      s_height=(int)(1.0*i*sumlim(terminal->v.stty.bcsr,-terminal->v.stty.tstart,terminal->v.stty.bsize)/k);
      s_top=terminal->y+10+(int)(1.0*i*sumlim(terminal->v.stty.tstart,-terminal->v.stty.bstart,terminal->v.stty.bsize)/k);
    }
    else {s_height=terminal->dy-20; s_top=terminal->y+10;}
    bar(terminal->x+terminal->v.stty.dxtty+5,terminal->y+10,terminal->x+terminal->v.stty.dxtty+11,s_top);
    bar(terminal->x+terminal->v.stty.dxtty+5,s_top+s_height,terminal->x+terminal->v.stty.dxtty+11,terminal->y+terminal->dy-10);
    if (s_height>0) square(terminal->x+terminal->v.stty.dxtty+5,s_top,6,s_height,0,1);
    direct_output();
  }
  m_pages=-1;
}

/* Routines for object creation */

Xv_opaque xv_create(xv_package obj_type)
{
  int j;
  Xv_opaque obj;

  if (!(obj=(Xv_opaque)malloc(sizeof(widget)))) return NULL;
  if ((obj_type!=frame) && (obj_type!=menu)) {
    obj->next=w_base->next;
    w_base->next=obj;
  }
  else obj->next=NULL;
  o_base=obj;
  obj->notify_handler=(xv_handler)nothing;
  obj->event_handler=(xv_handler)nothing;
  obj->menu_name=NULL;
  obj->o_type=obj_type;
  obj->fore_color=c_black;
  obj->back_color=c_white;
  obj->client_data=normal_client_data;
  obj->x=0; obj->y=0; obj->dy=12; obj->dx=99; strcpy(obj->xv_label,"");
  switch (obj->o_type) {
    case (frame):
      obj->v.sframe.mapped=0;
      /* over and under are inicialized em "open_window" */
      obj->v.sframe.adjust_exit=1;
      obj->v.sframe.Pw=NULL; /* NULL if there is no saved image */
      obj->v.sframe.dxmin=99;
      obj->v.sframe.dymin=99;
      obj->dy=99;
      w_base=obj;
      obj->v.sframe.mouse_obj=NULL;
      break;
    case menu:
    case setting:
      obj->v.smenu.itens_menu=0;
      obj->v.smenu.sel_menu=0;
      for (j=0; j<m_itens; j++) {
        obj->v.smenu.item_menu[j]=NULL;
        obj->v.smenu.item_submenu[j]=NULL;
      }
      break;
    case textfield:
      obj->v.stextfield.value_length=normal_length;
      strcpy(obj->v.stextfield.panel_value,"");
      obj->v.stextfield.panel_int=0;
      obj->v.stextfield.panel_real=0.0;
      obj->v.stextfield.min_value=-32767; obj->v.stextfield.max_value=32767;
      obj->v.stextfield.field_type=text_field;
      break;
    case tty:
      obj->v.stty.tty_xext=1; obj->v.stty.tty_yext=1;
      obj->v.stty.bsize=normal_bsize;
      if (!(obj->v.stty.Pb=(char *)malloc(obj->v.stty.bsize+1))) return NULL;
      obj->v.stty.bstart=0; obj->v.stty.tstart=0; obj->v.stty.tend=0;
      break;
    case button:
    case message:
      obj->v.sbutton.icon_label=0;
      obj->v.sbutton.Pimageb=NULL;
      break;
    case canvas:
      obj->v.scanvas.can_xext=1; obj->v.scanvas.can_yext=1;
  }
  obj->owner=w_base;
  return obj;
}

void item_create(const char * txt) /* Vale para Menu e Setting */
{
  if (o_base->v.smenu.itens_menu<m_itens) {
    o_base->v.smenu.itens_menu++;
    o_base->v.smenu.item_menu[o_base->v.smenu.itens_menu-1]=(char *) txt;
  }
}

/* Routines used by the window manager */

void wait_button(void)
{
  do mouse_read(); while (mouseb);
}

void redraw_background(Xv_opaque w, int desalocar)
{
  if (w->v.sframe.Pw!=NULL) {
    putfigure(w->x,w->y,w->v.sframe.Pw,COPY_PUT);
    if (desalocar) {
      freefiguremem(w->v.sframe.Pw);
      w->v.sframe.Pw=NULL;
    }
  }
  else {
    setfillstyle(type_hatch,c_hatch);
    bar(w->x,w->y,w->x+w->dx,w->y+w->dy);
  }
}

int conflicts(Xv_opaque w,int xx,int yy,int dxx,int dyy)
{
  int bate;

  if (w->x >= xx) bate = w->x <= xx+dxx;
  else bate = xx <= w->x+w->dx;
  if (bate) {
    if (w->y >= yy) bate=w->y <= yy+dyy;
    else bate = yy <= w->y+w->dy;
  }
  return bate;
}

int something_below(Xv_opaque w,int xx,int yy,int dxx,int dyy)
{
  int bate;
  if (wallpaper) return(1);
  bate=0;
  while (!bate && (w!=active_w->v.sframe.over)) {
    w=w->v.sframe.under;
    bate=conflicts(w,xx,yy,dxx,dyy);
  }
  return(bate);
}

void write_frame_label(Xv_opaque w)
{
  int i;
  xv_label_type temp;

  setviewport(w->x,w->y,w->x+w->dx,w->y+w->dy,1);
  square(mrgx,mrgx,w->dx-2 *mrgx,12,1,1);
  setcolor(w->fore_color);
  settextjustify(CENTER_TEXT,TOP_TEXT);
  /* No better way to clip a text? */
  strcpy(temp,w->xv_label);
  if (strlen(temp)>(i=(w->dx-2*mrgx)/8)) temp[i]='\0';
  outtextxy(w->dx/2,mrgx+3,temp);
  settextjustify(LEFT_TEXT,TOP_TEXT);
}

void draw_object(Xv_opaque obj,int active) /* Draws all the objects */
{
  int i,k,xx;
  Xv_opaque pto;
  xv_label_type temp;

  if (obj->o_type==textfield || obj->o_type==setting) {
    obj->dx=4+strlen(obj->xv_label)*8;
    if (redrawing_frame) {
      setcolor(obj->fore_color);
      outtextxy(obj->x+3,obj->y+3,obj->xv_label);
    }
  }
  switch (obj->o_type) {
    case frame:
      total_view();
      square(obj->x,obj->y,obj->dx,obj->dy,0,1);
      write_frame_label(obj);
      setcolor(c_light);
      moveto(obj->dx-2*mrgx+1,obj->dy);
      linerel(0,1-mrgx); linerel(mrgx,0); linerel(0,-mrgx); linerel(mrgx-1,0);
      window_view(obj);
      getviewsettings(&obj->v.sframe.gr_out);
      pto=obj->next;
      redrawing_frame=1;
      while (pto!=NULL) {
	draw_object(pto,0);
        pto=pto->next;
      }
      redrawing_frame=0;
      break;
    case button:
      if (obj->v.sbutton.icon_label) {
        if (redrawing_frame) {
          drawbitmap(obj->x+3,obj->y+3,&obj->dx,&obj->dy,&obj->v.sbutton.Pimageb,obj->xv_label);
          obj->dx+=6; obj->dy+=6;
        }
        square(obj->x,obj->y,obj->dx,obj->dy,active,0);
      }
      else {
        obj->dx=8*strlen(obj->xv_label)+4;
        square(obj->x,obj->y,obj->dx,obj->dy,active,1);
        setcolor(obj->fore_color);
        outtextxy(obj->x+3,obj->y+3,obj->xv_label);
      }
      break;
    case message:
      if (obj->v.smessage.icon_msg) {
        if (redrawing_frame) {
          drawbitmap(obj->x,obj->y,&obj->dx,&obj->dy,&obj->v.smessage.Pimagem,obj->xv_label);
	}
      }
      else {
        obj->dx=8*strlen(obj->xv_label)+4;
        setcolor(obj->fore_color);
        outtextxy(obj->x+3,obj->y+3,obj->xv_label);
      }
      break;
    case textfield:
      if (obj->v.stextfield.field_type==int_field) sprintf(obj->v.stextfield.panel_value,"%d",obj->v.stextfield.panel_int);
      else if (obj->v.stextfield.field_type==real_field) sprintf(obj->v.stextfield.panel_value,"%g",obj->v.stextfield.panel_real);
      xx=obj->v.stextfield.value_length *8+4;
      square(obj->x+obj->dx,obj->y+10,xx,2,0,1);
      bar(obj->x+obj->dx+3,obj->y,obj->x+obj->dx+xx-3,obj->y+7);
      setcolor(obj->fore_color);
      strcpy(temp,obj->v.stextfield.panel_value);
      /* Outra daquelas limitacoes */
      if (strlen(temp)>(i=obj->v.stextfield.value_length)) temp[i]='\0';
      outtextxy(obj->x+obj->dx+3,obj->y,temp);
      obj->dx+=xx;
      break;
    case setting:
      for (i=1; i<=obj->v.ssetting.itens_setting; i++) {
        xx=strlen(obj->v.ssetting.item_setting[i-1])*8+5;
	if (obj->v.ssetting.exclusive) k=1<<(obj->v.ssetting.sel_setting-1);
	else k=obj->v.ssetting.sel_setting;
        square(obj->x+obj->dx,obj->y,xx-1,obj->dy,(k & (1 << (i-1))),1);
        setcolor(obj->fore_color);
        outtextxy(obj->x+obj->dx+3,obj->y+3,obj->v.ssetting.item_setting[i-1]);
        obj->dx+=xx;
      }
      break;
    case canvas:
      setcolor(obj->fore_color);
      setfillstyle(SOLID_FILL,obj->back_color);
      if (obj->v.scanvas.can_xext) obj->dx=active_w->dx-2 *mrgx-obj->x;
      if (obj->v.scanvas.can_yext) obj->dy=active_w->dy-mrgx-mrgy-obj->y;
      bar3d(obj->x,obj->y,obj->x+obj->dx,obj->y+obj->dy,0,0);
      { struct viewporttype *with2=&active_w->v.sframe.gr_out;
        with2->left=active_w->x+obj->x+mrgx+1;
        with2->right=active_w->x+obj->x+obj->dx+mrgx-1;
        with2->top=active_w->y+obj->y+mrgy+1;
        with2->bottom=active_w->y+obj->y+obj->dy+mrgy-1;
        with2->clip=1;
      }
      callback(obj->notify_handler,obj);
      break;
    case tty:
      if (obj->v.stty.tty_xext) obj->dx=active_w->dx-2*mrgx-obj->x;
      if (obj->v.stty.tty_yext) obj->dy=active_w->dy-mrgx-mrgy-obj->y;
      obj->v.stty.dxtty=obj->dx-13;
      /* scrollbar */
      square(obj->x+obj->v.stty.dxtty+3,obj->y,10,obj->dy,1,1);
      moveto(obj->x+obj->v.stty.dxtty+5,obj->y+8);
      setcolor(c_shadow);
      linerel(6,0);
      linerel(-3,-6);
      linerel(-3,5);
      set_fill(c_normal);
      floodfill(getx()+2,gety()-2,c_shadow);
      setcolor(c_light);
      linerel(3,-5);
      moveto(obj->x+obj->v.stty.dxtty+5,obj->y+obj->dy-8);
      linerel(6,0);
      linerel(-3,6);
      linerel(-3,-5);
      set_fill(c_normal);
      floodfill(getx()+2,gety()+2,c_light);
      setcolor(c_shadow);
      moverel(6,-1);
      linerel(-3,6);
      obj->v.stty.yc=obj->dy;
      obj->v.stty.bcsr=obj->v.stty.tstart;
      /* desenha texto */
      m_pages=1;
      ttysw_output(obj,"");
      window_view(obj->owner);
  }
}

void xv_init(int placa,int modo) /* Inicialization */
{
  int i;
  initgraph(&placa,&modo,getenv("TCBGI"));
  i=graphresult();
  if (i!=grOk) {
    restorecrtmode();
    puts(grapherrormsg(i));
    return;
  }
  mouse_init();
#ifdef __TURBOC__
  if (getmaxcolor()<4) {
    c_normal=1;
    c_active=2;
    c_light=3;
    c_white=3;
    c_overwrite=3;
    c_edit=0;
    c_insert=2;
    c_hatch=1;
  }
  if (getmaxcolor()==1) {
    c_normal=0;
    c_active=1;
    c_light=1;
    c_white=1;
    c_overwrite=1;
    c_insert=1;
  }
  if (getmaxx()==319) x_factor=2;
#endif
  if (!wallpaper) {
    setfillstyle(type_hatch,c_hatch);
    bar(0,0,getmaxx(),getmaxy());
  }
  insert=0;
  active_w=NULL;
  interposer=nointerpose;
}

void Editar(xv_label_type linha,int x,int y,int cursor,int tlinha)
/* tty line editor */
{
  int base,i;
  int fim,primeira;
  char r,ec;
  char temp[2];

  base=1;
  fim=0; primeira=1;
  temp[1]='\0';
  set_fill(c_normal);
  do {
    moveto(x,y);
    i=base;
    while ((i-base<tlinha) && ((i<=strlen(linha)) || (i == cursor))) {
      bar(getx(),y,getx()+7,y+7);
      if (i==cursor) {
        if (insert) setcolor(c_insert);
        else setcolor(c_overwrite);
        if ((linha[i-1]=='\0') || (linha[i-1]==' ')) r='_';
        else r=linha[i-1];
      }
      else {
        r=linha[i-1];
        setcolor(c_edit);
      }
      temp[0]=r;
      outtext(temp);
      i++;
    }
    bar(getx(),y,x+tlinha*8-1,y+7);
    ec=getch();
    switch (ec) {
      case '\0': switch (getch()) {
        case 'K': if (cursor>1) cursor--;
          break;
        case 'M': if ((cursor<=strlen(linha)) && (cursor<m_chars)) cursor++;
          break;
        case 'G': cursor=1;
          break;
        case 'O': cursor=strlen(linha)+1;
          break;
        case 'R': insert=!insert;
          break;
        case 'S': for(i=cursor;linha[i-1]!='\0';i++) linha[i-1]=linha[i];
          break;
        }
        break;
      case '\b': if (cursor>1) {
	cursor--;
        for(i=cursor;linha[i-1]!='\0';i++) linha[i-1]=linha[i];
      }
        break;
      case '\r': fim=1;
        break;
      case '\x12': strcpy(linha,ulttxt);
        break;
      default: if (ec>27) {
        if (primeira) {
          linha[0]=ec; linha[1]='\0';
          cursor=2;
        }
        else {
          if (insert && ((i=strlen(linha))<m_chars)) {
            for (i++; i>=cursor; i--) linha[i]=linha[i-1];
            linha[cursor-1]=ec;
          }
          else {
	    if (linha[cursor-1] == '\0') linha[cursor]='\0';
            linha[cursor-1]=ec;
          }
        if (cursor<m_chars) cursor++;
        }
      }
    }
    if (cursor<base) base=cursor;
    else
      if (cursor>=base+tlinha) base=cursor-tlinha+1;
    primeira=0;
  } while (!(fim));
  strcpy(ulttxt,linha);
}

void menu_show(Xv_opaque obj) /* Menu processor */
{
  int i,j,menu_size,xm,ym,dxm,dym;
  int sair;
  ptrfig Pm;
  struct viewporttype VPnormal;

  if ((obj->o_type!=menu)) return; /* For safety */
  active_menu=NULL;
  if (base_menu==NULL) base_menu=obj;
  cursor_on();
  wait_button();
  getviewsettings(&VPnormal);
  total_view();
  xm=mousex; ym=mousey;
  dym=obj->v.smenu.itens_menu *8+16;
  menu_size=strlen(obj->xv_label);
  j=0;
  for (i=1; i<=obj->v.smenu.itens_menu; i++) {
    if (strlen(obj->v.smenu.item_menu[i-1])>menu_size) menu_size=strlen(obj->v.smenu.item_menu[i-1]);
    if (obj->v.smenu.item_submenu[i-1]!=NULL) j=16;
  }
  dxm=8*menu_size+4+j;
  size_adjust(&xm,&ym,&dxm,&dym,12,20);
  if ((Pm=getfiguremem(dxm,dym))!=0) {
    cursor_off();
    getfigure(xm,ym,xm+dxm,ym+dym,Pm);
    square(xm,ym,dxm,dym,0,1);
    square(xm+3,ym+11,dxm-6,2,0,1);
    setcolor(obj->fore_color);
    outtextxy(xm+3,ym+3,obj->xv_label);
    for (i=1; i<=obj->v.smenu.itens_menu; i++) {
      if (i==obj->v.smenu.sel_menu) setcolor(c_white); else setcolor(c_black);
      moveto(xm+3,ym+7+8 *i);
      outtext(obj->v.smenu.item_menu[i-1]);
      setcolor(c_black);
      if (obj->v.smenu.item_submenu[i-1]!=NULL) outtextxy(xm+dxm-8,gety(),">");
    }
    sair=0;
    cursor_on();
    do {
      mouse_read();
      i=0;
      if ((mousex>xm) && (mousex<xm+dxm)) i=(mousey-ym-7)/8;
      if ((i<1) || (i>obj->v.smenu.itens_menu)) i=0;
      if ((i!=0) && (i!=obj->v.smenu.sel_menu)) { /* remove i<>0 to retain selection */
	cursor_off();
	if (obj->v.smenu.sel_menu!=0) {
	  setcolor(c_black);
	  outtextxy(xm+3,ym+7+8 *obj->v.smenu.sel_menu,obj->v.smenu.item_menu[obj->v.smenu.sel_menu-1]);
	}
	obj->v.smenu.sel_menu=i;
	if (obj->v.smenu.sel_menu) {
	  setcolor(c_white);
	  outtextxy(xm+3,ym+7+8 *obj->v.smenu.sel_menu,obj->v.smenu.item_menu[obj->v.smenu.sel_menu-1]);
	}
	cursor_on();
      }
      if (mouseb) {
	if (mouseb>2) sair=1;
	else if (obj->v.smenu.sel_menu) {
	  if (mouseb==1) active_menu=obj;
	  else if ((mouseb==2) && (obj->v.smenu.item_submenu[obj->v.smenu.sel_menu-1]!=NULL))
	    menu_show(obj->v.smenu.item_submenu[obj->v.smenu.sel_menu-1]);
	}
	wait_button();
      }
    } while (!(sair || (active_menu!=NULL)));
    cursor_off();
    putfigure(xm,ym,Pm,COPY_PUT);
    freefiguremem(Pm);
    if (obj==base_menu) {
      base_menu=NULL; /* To allow for a callback opening a menu */
      if (active_menu!=NULL) callback(active_menu->notify_handler,active_menu);
    }
  }
  else impossible();
  /* cursor_on(); */
  { struct viewporttype *with2=&VPnormal;
    setviewport(with2->left,with2->top,with2->right,with2->bottom,with2->clip);
  }
}

/* Routines for window reordering (a complicated operation) */

void Flip(Xv_opaque w, int tst1, int tst2)
{
  if (tst1) {
    Pmove=getfiguremem(w->dx,w->dy);
    assert(Pmove!=NULL); /* Unavoidable. No way to predict success */
    getfigure(w->x,w->y,w->x+w->dx,w->y+w->dy,Pmove);
  }
  else Pmove=NULL;
  redraw_background(w,!tst1);
  if (tst2) {
#ifdef __GNUC__
   /* Impossible to move allocated memory (!?) */
   freefiguremem(w->v.sframe.Pw);
   w->v.sframe.Pw=Pmove;
#else
    movefigure(Pmove,w->v.sframe.Pw);
    freefiguremem(Pmove);
#endif
  }
  else w->v.sframe.Pw=Pmove;
}

void rearrange(Xv_opaque w, int back)
{
  Xv_opaque pti,ptf,ptw,ptt;
#ifdef __TURBOC__
  long int memoria;
#endif

  xv_ok=1;
  total_view();
  cursor_off();
  w->v.sframe.interfere=0;
  if (back) {
    pti=active_w;
    ptf=active_w->v.sframe.over;
  }
  else {
    pti=active_w;
    ptf=w;
    ptt=w->v.sframe.over;
    /* Remembers the first window to be redrawn */
  }
  /* Searches for the interfering windows */
  ptw=pti;
#ifdef __TURBOC__
  memoria=0;
#endif
  do {
    if (ptw!=w) {
      ptw->v.sframe.interfere=conflicts(ptw,w->x,w->y,w->dx,w->dy);
      /* The moving window is redrawn only if necessary */
      if (ptw->v.sframe.interfere) w->v.sframe.interfere=1;
    }
#ifdef __TURBOC__
    /* Measures the memory needed to remember the windows that are over the background */
    if (ptw->v.sframe.interfere) {
      ptw->v.sframe.areaw=figuresize(0,0,ptw->dx,ptw->dy);
      if (ptw->v.sframe.Pw==NULL) memoria+=ptw->v.sframe.areaw;
    }
#endif
    ptw=ptw->v.sframe.under;
  } while (!(ptw==ptf->v.sframe.under));
#ifdef __TURBOC__
  /* Verifies if there is memory enough to save all the windows
  to be moved, one at a time */
  ptw=pti;
  memoria=maxavail()-memoria;
  do {
    if (ptw->v.sframe.interfere) {
      if (ptw->v.sframe.areaw>memoria) {
	impossible();
	return;
      }
    }
    ptw=ptw->v.sframe.under;
  } while (!(ptw == ptf->v.sframe.under));
#endif
  /* Erases the windows to move, making them remember their images */
  ptw=pti;
  do {
    if (ptw->v.sframe.interfere) Flip(ptw,1,ptw->v.sframe.Pw!=NULL);
    ptw=ptw->v.sframe.under;
  } while (!(ptw==ptf->v.sframe.under));
  if (!back) {
    /* Removes the selected window */
    (w->v.sframe.under)->v.sframe.over=w->v.sframe.over;
    (w->v.sframe.over)->v.sframe.under=w->v.sframe.under;
    /* Inserts it above the active window */
    w->v.sframe.over=active_w->v.sframe.over;
    (active_w->v.sframe.over)->v.sframe.under=w;
    active_w->v.sframe.over=w;
    w->v.sframe.under=active_w;
  }
  /* Redraws the windows in reverse order, making them remember the background */
  if (back) { pti=active_w; ptf=active_w->v.sframe.under;}
  else { pti=ptt; ptf=w;}
  ptw=pti; active_w=ptf; /* Here, for the correct operation of "something_below" */
  do {
    if (ptw->v.sframe.interfere) {
      to_save=something_below(ptw,ptw->x,ptw->y,ptw->dx,ptw->dy);
      Flip(ptw,to_save,to_save);
    }
    ptw=ptw->v.sframe.over;
  } while (!(ptw == ptf->v.sframe.over));
}

void close_window(Xv_opaque w)
{
  if (w->v.sframe.mapped) {
    open_window(w);
    if (xv_ok) {
      total_view();
      cursor_off();
      redraw_background(w,1);
      w->v.sframe.mapped=0;
      if (w->v.sframe.under!=active_w) {
        active_w=w->v.sframe.under;
        direct_output();
        w->v.sframe.under->v.sframe.over=w->v.sframe.over;
        w->v.sframe.over->v.sframe.under=w->v.sframe.under;
      }
      else {
        xv_end=1;
	active_w=NULL;
      }
      callback(w->notify_handler,w);
    }
  }
}

void open_window(Xv_opaque w)
{
  xv_ok=1;
  if (active_w==NULL) {
    active_w=w;
    w->v.sframe.over=w;
    w->v.sframe.under=w;
  }
  if (!w->v.sframe.mapped) {
    w->v.sframe.over=active_w->v.sframe.over;
    w->v.sframe.under=active_w;
    size_adjust(&w->x,&w->y,&w->dx,&w->dy,w->v.sframe.dxmin,w->v.sframe.dymin);
    to_save=something_below(w,w->x,w->y,w->dx,w->dy);
    if (to_save) {
      total_view();
      w->v.sframe.Pw=getfiguremem(w->dx,w->dy);
    }
    if (!to_save || w->v.sframe.Pw) {
      active_w->v.sframe.over->v.sframe.under=w;
      active_w->v.sframe.over=w;
      active_w=w;
      if (to_save) getfigure(w->x,w->y,w->x+w->dx,w->y+w->dy,w->v.sframe.Pw);
      w->v.sframe.mapped=1; /* here to allow calls to xv_set in canvas notify handlers */
      draw_object(w,1);
      direct_output();
      if (w->v.sframe.mouse_obj!=NULL)
	if (w->v.sframe.mouse_obj==active_w) mouse_move(w->x+w->dx/2,w->y+mrgy/2);
	else mouse_move(w->x+mrgx+w->v.sframe.mouse_obj->x+w->v.sframe.mouse_obj->dx/2,w->y+mrgy+w->v.sframe.mouse_obj->y+6);
    }
    else impossible();
  }
  else if (w!=active_w) {
    rearrange(w,0);
    if (xv_ok) direct_output();
  }
}

void Back(void)
{
  rearrange(active_w,1);
  if (xv_ok) direct_output();
}
  
void xv_set(Xv_opaque obj, char * new_label) /* Changes labels */
{
  strcpy(obj->xv_label,new_label);
  if (obj->o_type!=menu) {
    open_window(obj->owner);
    if (xv_ok) {
      if (obj->o_type == frame) write_frame_label(obj);
      else {
        window_view(obj->owner);
        set_fill(c_normal);
        bar(obj->x,obj->y,obj->x+obj->dx,obj->y+obj->dy);
        redrawing_frame=1;
        draw_object(obj,0);
        redrawing_frame=0;
      }
    }
    direct_output();
  }
}

void xv_main_loop(Xv_opaque w) /* The notifier */
{
  int i,k,csr,dxm,dym,xini,yini,xx,yy,dxx,dyy,xant,yant;
  int found,resize;
  Xv_opaque pto,ptw;

  open_window(w);
  if (!xv_ok) return;
  wait_button();
  xv_end=0;
  do {
    cursor_on();
    /* Waits event */
    ie_code=-1;
    do {
      if (mkbhit()) {
	ie_code=getch();
#ifndef twocodes
        if (!ie_code) ie_code=2000+getch();
#endif
      }
      else {
        xant=mousex; yant=mousey; k=mouseb;
        mouse_read();
        if (k!=mouseb) ie_code=1000+k *10+mouseb;
        else if ((xant!=mousex) || (yant!=mousey)) {
          if (mouseb == 0) ie_code=LOC_MOVE;
          else ie_code=LOC_DRAG;
        }
      }
    } while (!(ie_code>=0));
    ie_shiftcode=mouseb;
    interposer();
   again:
    /* Verifies if the mouse is over some window */
    found=0;
    ptw=active_w;
    do {
      found=(mousex>=ptw->x) && (mousey>=ptw->y) && (mousex<=ptw->x+ptw->dx) && (mousey<=ptw->y+ptw->dy);
      if (!found) ptw=ptw->v.sframe.under;
    } while (!(found || (ptw==active_w)));
    if (found) {
      /* Verifies if the mouse is above some object */
      ie_locx=mousex-ptw->x-mrgx; ie_locy=mousey-ptw->y-mrgy;
      if ((ptw==active_w) && (ie_locx>=0) && (ie_locy>=0) && (ie_locx<=ptw->dx-2*mrgx) && (ie_locy<=ptw->dy-mrgx-mrgy)) {
	found=0;
	pto=ptw->next;
	while ((pto!=NULL) && !found) {
	  found=(ie_locx>=pto->x) && (ie_locx<=pto->x+pto->dx) && (ie_locy>=pto->y) && (ie_locy<=pto->y+pto->dy);
	  if (!found) pto=pto->next;
	}
      }
      else pto=NULL;
      active_o=pto;
      if (active_o!=NULL) {
        window_view(ptw);
        /* Treats event */
        ie_locx-=active_o->x; ie_locy-=active_o->y;
	if (ie_code==MS_LEFT) {
          cursor_off();
          switch (active_o->o_type) {
            case button:
              draw_object(active_o,1);
              cursor_on();
	      wait_button();
	      cursor_off();
	      draw_object(active_o,0);
              break;
            case textfield:
              csr=strlen(active_o->v.stextfield.panel_value)+1;
              do {
                Editar(active_o->v.stextfield.panel_value,active_o->x+textwidth(active_o->xv_label)+7,active_o->y,csr,active_o->v.stextfield.value_length);
                csr=0;
                if (active_o->v.stextfield.field_type!=text_field)
                  active_o->v.stextfield.panel_real=atof(active_o->v.stextfield.panel_value);
                if (active_o->v.stextfield.field_type==int_field)
                  if ((active_o->v.stextfield.panel_real<=active_o->v.stextfield.max_value) && (active_o->v.stextfield.panel_real>=active_o->v.stextfield.min_value)) active_o->v.stextfield.panel_int=(int)active_o->v.stextfield.panel_real;
		  else csr=strlen(active_o->v.stextfield.panel_value);
              } while (!((active_o->v.stextfield.field_type==text_field) || (!csr)));
              draw_object(active_o,0);
              break;
            case setting:
              csr=strlen(active_o->xv_label)*8+4; i=0;
              if (ie_locx>csr) {
                do {
                  i++;
                  k=strlen(active_o->v.ssetting.item_setting[i-1])*8+5;
                  csr+=k;
                } while (!((csr>=ie_locx) || (i==active_o->v.ssetting.itens_setting)));
                xx=1 << (i-1);
                if (active_o->v.ssetting.exclusive) active_o->v.ssetting.sel_setting=i;
                else active_o->v.ssetting.sel_setting=(active_o->v.ssetting.sel_setting ^ xx);
                draw_object(active_o,0);
              }
              break;
            case tty: if (ie_locx>active_o->dx-11) {
	      i=0;
	      if (ie_locy>active_o->dy-10) {
		while (active_o->v.stty.tstart!=active_o->v.stty.bcsr && i==0) {
		  if (active_o->v.stty.Pb[active_o->v.stty.tstart]=='\n') i++;
		  inclim(&active_o->v.stty.tstart,active_o->v.stty.bsize);
		}
	      }
	      else {
		if (ie_locy>=10) {
		  active_o->v.stty.tstart=sumlim(active_o->v.stty.bstart,(unsigned int)(1.0*sumlim(active_o->v.stty.tend,-active_o->v.stty.bstart,active_o->v.stty.bsize)*(ie_locy-10)/(active_o->dy-20)),active_o->v.stty.bsize);
		  k=1;
		}
		else k=2;
		if (active_o->v.stty.tstart!=active_o->v.stty.bstart) {
		  do {
		    declim(&active_o->v.stty.tstart,active_o->v.stty.bsize);
		    if (active_o->v.stty.Pb[active_o->v.stty.tstart]=='\n') i++;
		  }
		  while (!((active_o->v.stty.tstart==active_o->v.stty.bstart) || (i==k)));
		  if (active_o->v.stty.tstart!=active_o->v.stty.bstart) inclim(&active_o->v.stty.tstart,active_o->v.stty.bsize);
		}
	      }
	      active_o->v.stty.bcsr=active_o->v.stty.tstart;
	      active_o->v.stty.yc=active_o->dy;
	      m_pages=1;
	      ttysw_output(active_o,"");
	    }
	  }
	  if (active_o->o_type!=canvas) {
            callback(active_o->notify_handler,active_o);
            goto proceed;
          }
	}
	if ((ie_code == MS_RIGHT) && (active_o->menu_name!=NULL)) {
          menu_show(active_o->menu_name);
          goto proceed;
        }
	callback(pto->event_handler,pto);
       proceed:
      }
      else {
        /* Treats windows */
        if (ie_code>1000 && ie_code<1010)
          /* Opens a window and repeats the event */
          if (active_w!=ptw) { open_window(ptw); if (xv_ok) goto again; }
	  else {
            if ((ie_code==MS_RIGHT) && (ptw->menu_name!=NULL)) menu_show(ptw->menu_name);
            else if ((ie_code>MS_RIGHT) && ptw->v.sframe.adjust_exit) {
              wait_button();
	      close_window(ptw);
	    }
	    else if (ie_code==MS_LEFT) {
	      resize=(abs(mousex-ptw->x-ptw->dx)<10) && (abs(mousey-ptw->y-ptw->dy)<10);
	      total_view();
	      setcolor(c_white);
	      setwritemode(XOR_PUT);
	      xini=ptw->x; yini=ptw->y;
	      cursor_off();
	      xx=ptw->x; yy=ptw->y; dxx=ptw->dx; dyy=ptw->dy;
	      rectangle(xx,yy,xx+dxx,yy+dyy);
	      do {
		xant=mousex; yant=mousey;
		mouse_read();
		if ((mousex!=xant) || (mousey!=yant)) {
		  dxm=mousex-xant;
		  dym=mousey-yant;
		  rectangle(xx,yy,xx+dxx,yy+dyy);
		  if (resize) {
		    dxx+=dxm;
		    dyy+=dym;
		  }
		  else {
		    xx+=dxm;
		    yy+=dym;
		  }
		  rectangle(xx,yy,xx+dxx,yy+dyy);
		}
	      } while (mouseb);
	      rectangle(xx,yy,xx+dxx,yy+dyy);
	      setwritemode(COPY_PUT);
	      if ((ptw->x!=xx) || (ptw->y!=yy) || (ptw->dx!=dxx) || (ptw->dy!=dyy)) {
		size_adjust(&xx,&yy,&dxx,&dyy,ptw->v.sframe.dxmin,ptw->v.sframe.dymin);
		to_save=something_below(ptw,xx,yy,dxx,dyy);
		/*
		   Allocation of the destination background image.
		   Allocated first to minimize heap fragmentation, if
		   there is no stored image (Pw=NULL) or in resize.
		*/
		if (to_save && (resize || ptw->v.sframe.Pw==NULL)) xv_ok=((Ptemp=getfiguremem(dxx,dyy))!=NULL);
		else { xv_ok=1; Ptemp=NULL; }
		/* Allocation of the window image to move */
		if (xv_ok && !resize) Pmove=getfiguremem(dxx,dyy);
		else Pmove=NULL;
		/* If the window was over the background, Pw=NULL */
		/* If Pmove=NULL, the window will be redrawn */
		if (xv_ok) {
		  if (!resize) {
		    /* The window image to be moved */
		    if (Pmove) getfigure(ptw->x,ptw->y,ptw->x+ptw->dx,ptw->y+ptw->dy,Pmove);
		  }
		  /*
		    The deallocation of Pw must occur only in resize and
		    in the movement of a window to the background
		  */
		  redraw_background(ptw,(!to_save) || resize);
		  ptw->x=xx; ptw->y=yy; ptw->dx=dxx; ptw->dy=dyy;
		  if (to_save) {
		    if (Ptemp) ptw->v.sframe.Pw=Ptemp;
		    getfigure(xx,yy,xx+dxx,yy+dyy,ptw->v.sframe.Pw);
		  }
		  if (Pmove) {
		    putfigure(xx,yy,Pmove,COPY_PUT);
		    freefiguremem(Pmove);
		    { struct viewporttype *with2=&ptw->v.sframe.gr_out;
		      dxm=xx-xini; dym=yy-yini;
		      with2->left=with2->left+dxm; with2->top=with2->top+dym; with2->right=with2->right+dxm; with2->bottom=with2->bottom+dym;
		    }
		  }
		  else {
		    if (Ptemp) ptw->v.sframe.Pw=Ptemp;
		    draw_object(ptw,1);
		  }
		}
		else impossible();
	      }
	    }
	  }
	else callback(ptw->event_handler,ptw);
      }
    }
  } while (!(xv_end));
}

