#include <stdlib.h>
#include <dos.h>
#include <dpmi.h>
#include <gppconio.h>
#include <mousex.h>
/*
 Mouse interface for the Xview-PC interface - djgpp version.
 By Antonio Carlos Moreirao de Queiroz - acmq@coe.ufrj.br
 V. 1.0 - 04/07/94
 V. 1.0a - 22/07/94 Emulator implemented, mevent is static
 V. 1.0b - 22/07/94 GRX functions only
*/

int mousex,mousey,mouseb;
int cursor_active,teclado;

static MouseEvent mevent;
static _go32_dpmi_registers regs;
static int emulacao,incr;
static GrCursor *ecursor;
static char seta[] = {
    1,1,0,0,0,0,0,0,0,0,0,0,
    1,2,1,0,0,0,0,0,0,0,0,0,
    1,2,2,1,0,0,0,0,0,0,0,0,
    1,2,2,2,1,0,0,0,0,0,0,0,
    1,2,2,2,2,1,0,0,0,0,0,0,
    1,2,2,2,2,2,1,0,0,0,0,0,
    1,2,2,2,2,2,2,1,0,0,0,0,
    1,2,2,2,2,2,2,2,1,0,0,0,
    1,2,2,2,2,2,2,2,2,1,0,0,
    1,2,2,2,2,2,2,2,2,2,1,0,
    1,2,2,2,2,2,2,2,2,2,2,1,
    1,2,2,2,2,1,1,1,1,1,1,1,
    1,2,2,2,1,0,0,0,0,0,0,0,
    1,2,2,1,0,0,0,0,0,0,0,0,
    1,2,1,0,0,0,0,0,0,0,0,0,
    1,1,0,0,0,0,0,0,0,0,0,0,
};

int EmulacaoAtiva(void)
{
  regs.x.ax=0x0200;
  _go32_dpmi_simulate_int(0x16,&regs);
  return (regs.x.ax & 0x0010)==0; /* ScrollLock inactive */
}

int Shift(void)
{
  return (regs.x.ax & 0x0040)!=0; /* CapsLock active */
}

/* Inicializes mouse */

void mouse_init(void)
{

  int cols[3];

  mouseb=0; mousex=0; mousey=0;
  if (MouseDetect()) {
    MouseSetColors(WHITE,BLACK);
    emulacao=0;
    cursor_active=0;
    teclado=0;
  }
  else {
    cols[0]=2;
    cols[1]=BLACK;
    cols[2]=YELLOW;
    ecursor=GrBuildCursor(seta,12,16,1,1,cols);
    mousex=GrScreenX()/2;
    mousey=GrScreenY()/2;
    cursor_active=0;
    incr=8;
    emulacao=1;
    GrMoveCursor(ecursor,mousex,mousey);
  }
}

/* Shows cursor */

void cursor_on(void)
{
  if (!cursor_active) {
    if (emulacao) GrDisplayCursor(ecursor);
    else MouseDisplayCursor();
    cursor_active=1;
  }
}

/* Hides cursor */

void cursor_off(void)
{
  if (cursor_active) {
    if (emulacao) GrEraseCursor(ecursor);
    else MouseEraseCursor();
    cursor_active=0;
  }
}

/* Moves cursor */

void mouse_move(int x,int y)
{
int tinha_cursor;

  tinha_cursor=cursor_active;
  if (cursor_active) cursor_off();
  if (x>=GrScreenX()) x=GrScreenX()-1;
  if (x<0) x=0;
  if (y>=GrScreenY()) y=GrScreenY()-1;
  if (y<0) y=0;
  mousex=x;
  mousey=y;
  if (emulacao) GrMoveCursor(ecursor,x,y);
  else MouseWarp(x,y);
  if (tinha_cursor) cursor_on();
}

int xkbhit(void) /* returns the scan code and the key code */
{
  regs.x.ax=0x0100;
  _go32_dpmi_simulate_int(0x16,&regs);
  return ((regs.x.flags & 0x0040)==0);
}

/* Reads the mouse current position and buttons */

void mouse_read(void)
{
  if (emulacao) {
    if (!EmulacaoAtiva()) return;
    if (!Shift()) mouseb=0;
    if (teclado) {
       regs.x.ax=0;
       _go32_dpmi_simulate_int(0x16,&regs);
    }
    teclado=0;
    if (xkbhit()) {
      switch (regs.x.ax >> 8) {
        case 0x4B:mouse_move(mousex-incr,mousey); break;
        case 0x4D:mouse_move(mousex+incr,mousey); break;
        case 0x48:mouse_move(mousex,mousey-incr); break;
        case 0x50:mouse_move(mousex,mousey+incr); break;
        case 0x47:incr=1; break;
        case 0x49:incr=32; break;
        case 0x51:incr=8; break;
        case 0x1C:mouseb=mouseb ^ 1; break;
        case 0x01:mouseb=mouseb ^ 4; break;
        case 0x39:mouseb=mouseb ^ 2; break;
#ifdef twocodes
        case 0x00:teclado=1; break;
        default:teclado=regs.x.ax & 0x00ff;
#else
        default:teclado=1;
#endif
      }
      if (!teclado) {
        regs.x.ax=0;
        _go32_dpmi_simulate_int(0x16,&regs);
      }
    }
  }
  else {
    MouseGetEvent((M_POLL | M_EVENT) & (~M_KEYPRESS),&mevent);
    mousex=mevent.x;
    mousey=mevent.y;
    mouseb=mevent.buttons;
  }
}

int mkbhit(void)
{
int temp;
  if (emulacao && cursor_active && EmulacaoAtiva()) temp=teclado;
  else temp=kbhit();
  teclado=0;
  return temp;
}
