#ifdef __GNUC__
#include <std.h>
#include <gppconio.h>
#include <libbcc.h>
#include <pc.h>
#include <dpmi.h>
#else
#include <graphics.h>
#include <alloc.h>
#include <dos.h>
#include <conio.h>
#endif

/*
 Mouse interface for the Xview-PC interface - Turbo C version.
 By Antonio Carlos Moreirao de Queiroz - acmq@coe.ufrj.br
 V. 2.1a - 16/07/92 C version
 V. 2.2  - 02/09/92 ScrollLock contrls emulation and CapsLock retention
 V. 2.3  - 26/09/92 Normal keys processed normally
 V. 2.3a - 27/10/92 Clears keyboard buffer in mouse_read in emulation
 V. 2.3b - 10/03/94 Function mkbhit; extended events
 V. 2.3c - 23/06/94 Static local variables
 V. 2.3d - 05/02/95 Mouse_move corrected
 V. 2.4  - 11/03/95 mousex and mousey can be changed, x_factor changed
 V. 2.5  - 05/07/96 Draws the cursor. Works with BC and GNUC (djgpp V2)
 V. 2.5a - 27/08/96 mouse_move moves the cursor correctly
 V. 2.5b - 09/10/96 SVGA size expansion removed (problems with Windows 95)
 V. 2.5c - 03/11/96 Added dummy instruction to cursor_off
*/

int mousex,mousey,mouseb,cursor_active;

#ifdef __GNUC__
static __dpmi_regs regs;
#define r_ax x.ax
#define r_bx x.bx
#define r_cx x.cx
#define r_dx x.dx
#define r_flags x.flags
#define intr(xx,yy) __dpmi_int(xx,yy)
#else
static struct REGPACK regs;
#endif
static int emulation,key_pending;
static struct viewporttype VP;
static int cor,incr,cursorx,cursory;
static void *pt;

/* Mouse sensitivity and cursor colors */
#define cursor_x_sensitivity 8
#define cursor_y_sensitivity 16
#define expansion 1
#define cursor_border WHITE
#define cursor_fill BLACK

/* Cursor shapes */
/*
#define cursor_size 8
#define cursor_points 7
static cursor_poly[14]={0,0, 8,0, 6,2, 8,4, 4,8, 2,6, 0,8};
*/
/*
#define cursor_size 18
#define cursor_points 15
static cursor_poly[30]={0,0, 10,0, 8,2, 14,2, 12,4, 18,4, 14,8, 18,12,
                        12,18, 8,14, 4,18, 4,12, 2,14, 2,8, 0,10};
*/
/*
#define cursor_size 12
#define cursor_points 7
static cursor_poly[14]={0,0, 12,0, 9,3, 12,6, 6,12, 3,9, 0,12};
*/
#define cursor_size 9
#define cursor_points 7
static cursor_poly[14]={0,0, 9,0, 7,2, 9,4, 4,9, 2,7, 0,9};

int emulation_active(void)
{
  regs.r_ax=0x0200;
  intr(0x16,&regs);
  return (regs.r_ax & 0x0010)==0; /* ScrollLock inactive */
}

int Shift(void)
{
  /*
  regs.r_ax:=0x0200;
  intr(0x16,&regs);
  */
  return (regs.r_ax & 0x0043)!=0; /* CapsLock or shift active */
}

void Prepare(void)
{
  getviewsettings(&VP);
  cor=getcolor();
  setviewport(0,0,getmaxx(),getmaxy(),1);
}

void Restore(void)
{
  setviewport(VP.left,VP.top,VP.right,VP.bottom,VP.clip);
  setcolor(cor);
}

/* Inicializes mouse */

void mouse_init(void)
{
  mouseb=0;
  mousex=getmaxx()>>1;
  mousey=getmaxy()>>1;
  cursor_active=0;
  key_pending=0;
  regs.r_ax=0x0000;
  intr(0x33,&regs);
  emulation=(regs.r_ax==0x0000);
  if (!emulation) {
    regs.r_ax=0x0007;
    regs.r_cx=0x0000;
    regs.r_dx=getmaxx()*expansion;
    intr(0x33,&regs);
    regs.r_ax=0x0008;
    regs.r_cx=0x0000;
    regs.r_dx=getmaxy()*expansion;
    intr(0x33,&regs);
    regs.r_ax=0x000F;
    regs.r_cx=cursor_x_sensitivity;
    regs.r_dx=cursor_x_sensitivity;
    intr(0x33,&regs);
    regs.r_ax=0x0004;
    regs.r_cx=getmaxx()*expansion/2;
    regs.r_dx=getmaxy()*expansion/2;
    intr(0x33,&regs);
  }
  pt=malloc(imagesize(0,0,cursor_size,cursor_size));
  cursorx=mousex;
  cursory=mousey;
  incr=8;
}

/* Shows cursor */

void cursor_on(void)
{
int lx;

  if (!cursor_active) {
    Prepare();
    lx=cursorx+cursor_size; if (lx>getmaxx()) lx=getmaxx();
    getimage(cursorx,cursory,lx,cursory+cursor_size,pt);
    setcolor(cursor_border);
    setfillstyle(SOLID_FILL,cursor_fill);
    setviewport(cursorx,cursory,getmaxx(),getmaxy(),1);
    fillpoly(cursor_points,cursor_poly);
    Restore();
    cursor_active=1;
  }
}

/* Hides cursor */

void cursor_off(void)
{
  if (cursor_active) {
    Prepare();
    putpixel(0,0,getpixel(0,0)); /* To work under Window 95 (Why?) */
    putimage(cursorx,cursory,pt,COPY_PUT);
    Restore();
    cursor_active=0;
  }
}

/* Moves cursor */

void mouse_move(int x,int y)
{
int had_cursor;

  had_cursor=cursor_active;
  if (cursor_active) cursor_off();
  if (x>getmaxx()) x=getmaxx();
  if (x<0) x=0;
  if (y>getmaxy()) y=getmaxy();
  if (y<0) y=0;
  mousex=cursorx=x;
  mousey=cursory=y;
  if (!emulation) {
    regs.r_ax=0x0004;
    regs.r_cx=x*expansion;
    regs.r_dx=y*expansion;
    intr(0x33,&regs);
  }
  if (had_cursor) cursor_on();
}

int xkbhit(void) /* returns the scan code and the key code */
{
  regs.r_ax=0x0100;
  intr(0x16,&regs);
  return ((regs.r_flags & 0x0040)==0);
}

/* Reads the mouse current position and buttons */

void mouse_read(void)
{
  if (emulation) {
    if (!emulation_active()) return;
    if (!Shift()) mouseb=0;
    if (key_pending) {
       regs.r_ax=0x0000;
       intr(0x16,&regs);
    }
    key_pending=0;
    if (xkbhit()) {
      switch (regs.r_ax >> 8) {
	case 0x4B:mouse_move(cursorx-incr,cursory); break;
	case 0x4D:mouse_move(cursorx+incr,cursory); break;
	case 0x48:mouse_move(cursorx,cursory-incr); break;
	case 0x50:mouse_move(cursorx,cursory+incr); break;
	case 0x47:incr=1; break;
	case 0x49:incr=32; break;
	case 0x51:incr=8; break;
	case 0x1C:mouseb=mouseb ^ 1; break;
	case 0x01:mouseb=mouseb ^ 4; break;
	case 0x39:mouseb=mouseb ^ 2; break;
#ifdef twocodes
	case 0x00:key_pending=1; break;
	default:key_pending=regs.r_ax & 0x00ff;
#else
	default:key_pending=1;
#endif
      }
      if (!key_pending) {
	regs.r_ax=0x0000;
	intr(0x16,&regs);
      }
    }
  }
  else {
    regs.r_ax=0x0003;
    intr(0x33,&regs);
    mouseb=regs.r_bx;
    mousex=regs.r_cx/expansion;
    mousey=regs.r_dx/expansion;
    if (cursorx!=mousex || cursory!=mousey) mouse_move(mousex,mousey);
  }
}

int mkbhit(void)
{
int temp;
  if (emulation && cursor_active && emulation_active()) temp=key_pending;
  else temp=kbhit();
  key_pending=0;
  return temp;
}
