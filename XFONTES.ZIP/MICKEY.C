#include <graphics.h>
#include <alloc.h>
#include <dos.h>
#include <conio.h>

/*
 Mouse interface for the Xview-PC interface - Turbo C version.
 By Antonio Carlos Moreirao de Queiroz - acmq@coe.ufrj.br
 V. 2.1a - 16/07/92 C version
 V. 2.2  - 02/09/92 ScrollLock contrls emulation and CapsLock retention
 V. 2.3  - 26/09/92 Normal keys processed normally
 V. 2.3a - 27/10/92 Clears keyboard buffer in mouse_read in emulation
 V. 2.3b - 10/03/94 Function mkbhit; extended events
 V. 2.3c - 23/06/94 Static local variables
 V. 2.3d - 05/02/95 Mouse_move corrected
 V. 2.4  - 11/03/95 mousex and mousey can be changed, x_factor changed.
*/

int mousex,mousey,mouseb,x_factor;
int cursor_active,teclado;

static struct REGPACK regs;
static int emulacao;
static void *pt;
static struct viewporttype VP;
static int cor,incr,cursorx,cursory;

int EmulacaoAtiva(void)
{
  regs.r_ax=0x0200;
  intr(0x16,&regs);
  return (regs.r_ax & 0x0010)==0; /* ScrollLock inactive */
}

int Shift(void)
{
  /*
  regs.r_ah:=0x0200;
  intr(0x16,&regs);
  */
  return (regs.r_ax & 0x0040)!=0; /* CapsLock active */
}

void Prepare(void)
{
  getviewsettings(&VP);
  cor=getcolor();
  setviewport(0,0,getmaxx(),getmaxy(),1);
}

void Restore(void)
{
  setviewport(VP.left,VP.top,VP.right,VP.bottom,VP.clip);
  setcolor(cor);
}

/* Inicializes mouse */

void mouse_init(void)
{
  mouseb=0;
  mousex=getmaxx()>>1;
  mousey=getmaxy()>>1;
  cursor_active=0;
  x_factor=0;
  teclado=0;
  regs.r_ax=0x00;
  intr(0x33,&regs);
  if (regs.r_ax==0) {
    pt=malloc(imagesize(0,0,8,8));
    cursorx=mousex;
    cursory=mousey;
    incr=8;
    emulacao=1;
  }
  else emulacao=0;
}

/* Shows cursor */

void cursor_on(void)
{
static seta[14]={0,0, 8,0, 6,2, 8,4, 4,8, 2,6, 0,8};
/* Another cursor */
/*
static cruz[24]={2,0, 6,0, 6,2, 8,2, 8,6, 6,6, 6,8, 2,8,
		 2,6, 0,6, 0,2, 2,2};
*/

int lx;

  if (!cursor_active) {
    if (emulacao) {
      Prepare();
      lx=cursorx+8; if (lx>getmaxx()) lx=getmaxx();
      getimage(cursorx,cursory,lx,cursory+8,pt);
      setcolor(WHITE);
      setfillstyle(SOLID_FILL,BLACK);
      setviewport(cursorx,cursory,getmaxx(),getmaxy(),1);
      /* Optional different cursor for toggle mode */
      /*
      if (Shift()) fillpoly(12,cruz);
      else
      */
      fillpoly(7,seta);
      Restore();
    }
    else {
      regs.r_ax=0x01;
      intr(0x33,&regs);
    }
    cursor_active=1;
  }
}

/* Hides cursor */

void cursor_off(void)
{
  if (cursor_active) {
    if (emulacao) {
      Prepare();
      putimage(cursorx,cursory,pt,COPY_PUT);
      Restore();
    }
    else {
      regs.r_ax=0x02;
      intr(0x33,&regs);
    }
    cursor_active=0;
  }
}

/* Moves cursor */

void mouse_move(int x,int y)
{
int tinha_cursor;

  tinha_cursor=cursor_active;
  if (cursor_active) cursor_off();
  if (x>getmaxx()) x=getmaxx();
  if (x<0) x=0;
  if (y>getmaxy()) y=getmaxy();
  if (y<0) y=0;
  mousex=cursorx=x;
  mousey=cursory=y;
  if (!emulacao) {
    regs.r_ax=0x04;
    regs.r_cx=x<<x_factor;
    regs.r_dx=y;
    intr(0x33,&regs);
  }
  if (tinha_cursor) cursor_on();
}

int xkbhit(void) /* returns the scan code and the key code */
{
  regs.r_ax=0x0100;
  intr(0x16,&regs);
  return ((regs.r_flags & 0x0040)==0);
}

/* Reads the mouse current position and buttons */

void mouse_read(void)
{
  if (emulacao) {
    if (!EmulacaoAtiva()) return;
    if (!Shift()) mouseb=0;
    if (teclado) {
       regs.r_ax=0;
       intr(0x16,&regs);
    }
    teclado=0;
    if (xkbhit()) {
      switch (regs.r_ax >> 8) {
        case 0x4B:mouse_move(cursorx-incr,cursory); break;
        case 0x4D:mouse_move(cursorx+incr,cursory); break;
        case 0x48:mouse_move(cursorx,cursory-incr); break;
        case 0x50:mouse_move(cursorx,cursory+incr); break;
        case 0x47:incr=1; break;
        case 0x49:incr=32; break;
        case 0x51:incr=8; break;
        case 0x1C:mouseb=mouseb ^ 1; break;
        case 0x01:mouseb=mouseb ^ 4; break;
        case 0x39:mouseb=mouseb ^ 2; break;
#ifdef twocodes
        case 0x00:teclado=1; break;
        default:teclado=regs.r_ax & 0x00ff;
#else
        default:teclado=1;
#endif
      }
      if (!teclado) {
        regs.r_ax=0;
        intr(0x16,&regs);
      }
    }
  }
  else {
    regs.r_ax=0x03;
    intr(0x33,&regs);
    mouseb=regs.r_bx;
    mousex=regs.r_cx>>x_factor;
    mousey=regs.r_dx;
  }
}

int mkbhit(void)
{
int temp;
  if (emulacao && cursor_active && EmulacaoAtiva()) temp=teclado;
  else temp=kbhit();
  teclado=0;
  return temp;
}
