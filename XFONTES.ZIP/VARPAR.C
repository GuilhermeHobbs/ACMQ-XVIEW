/* Funcao com parametros variaveis */
/* ACMQ - 12/07/92 */

#include <stdarg.h>
#include <stdio.h>

enum atributo {TEXTO=1,INTEIRO,REAL};

void tratar(int fixo,...)
{
  va_list parametros;
  int tipo;
  char *texto;
  int inteiro;
  double real;

  printf("Fixo: %d\n",fixo);
  /* Inicializa a leitura da lista */
  va_start(parametros,fixo);
  /* Le o tipo */
  while ((tipo=va_arg(parametros,int))!=0) {
    switch (tipo) {
      case TEXTO: /* Le texto */
        texto=va_arg(parametros,char *);
        printf("Texto: %s\n",texto);
        break;
      case INTEIRO: /* Le int */
        inteiro=va_arg(parametros,int);
        printf("Inteiro: %d\n",inteiro);
        break;
      case REAL: /* Le double */
        real=va_arg(parametros,double);
        printf("Real: %g\n",real);
    }
  }
  va_end(parametros); /* Encerra a leitura */
}

void main()
{
  tratar(1,
	 TEXTO,"Isto e um texto",
	 INTEIRO,12345,
	 REAL,1.123e-20,
         TEXTO,"Outro texto de teste",
	 NULL);
  tratar(2,
         TEXTO,"Primeiro texto da segunda linha",
	 TEXTO,"acabou");
}

