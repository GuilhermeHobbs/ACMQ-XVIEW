#include <stdlib.h>
#include <dos.h>
#include <dpmi.h>
#include <gppconio.h>
#include <GRX20.h>
/*
 Mouse interface for the Xview-PC interface - djgpp version.
 By Antonio Carlos Moreirao de Queiroz - acmq@coe.ufrj.br
 V. 1.0 - 04/07/94
 V. 1.0a - 22/07/94 Emulator implemented, mevent is static
 V. 1.0b - 22/07/94 GRX functions only
 V. 1.1  - 14/04/95 mousex and mousey can be changed; Int 16 changed.
 V. 1.2  - 14/03/96 GRX20. In development.
           Missing dots in mouse cursor.
*/

#define INT16 __dpmi_int(0x16,&regs);

int mousex,mousey,mouseb,evkeyb;
int cursor_active,key_pending;
GrMouseEvent mevent;

static __dpmi_regs regs;
static int emulation,incr,cursorx,cursory;
static GrCursor *ecursor;
static char seta[] = {
    1,1,0,0,0,0,0,0,0,0,0,0,
    1,2,1,0,0,0,0,0,0,0,0,0,
    1,2,2,1,0,0,0,0,0,0,0,0,
    1,2,2,2,1,0,0,0,0,0,0,0,
    1,2,2,2,2,1,0,0,0,0,0,0,
    1,2,2,2,2,2,1,0,0,0,0,0,
    1,2,2,2,2,2,2,1,0,0,0,0,
    1,2,2,2,2,2,2,2,1,0,0,0,
    1,2,2,2,2,2,2,2,2,1,0,0,
    1,2,2,2,2,2,2,2,2,2,1,0,
    1,2,2,2,2,2,2,2,2,2,2,1,
    1,2,2,2,2,1,1,1,1,1,1,1,
    1,2,2,2,1,0,0,0,0,0,0,0,
    1,2,2,1,0,0,0,0,0,0,0,0,
    1,2,1,0,0,0,0,0,0,0,0,0,
    1,1,0,0,0,0,0,0,0,0,0,0,
};

int EmulacaoAtiva(void)
{
  regs.x.ax=0x0200;
  INT16;
  return (regs.x.ax & 0x0010)==0; /* ScrollLock inactive */
}

int Shift(void)
{
  return (regs.x.ax & 0x0040)!=0; /* CapsLock active */
}

/* Inicializes mouse */

void mouse_init(void)
{
  int cols[3];

  mouseb=0;
  mousex=GrScreenX()>>1;
  mousey=GrScreenY()>>1;
  cursor_active=0;
  key_pending=0;
  if (GrMouseDetect()) {
    GrMouseSetColors(WHITE,BLACK);
    emulation=0;
  }
  else {
    cols[0]=2;
    cols[1]=BLACK;
    cols[2]=YELLOW;
    ecursor=GrBuildCursor(seta,12,12,16,1,1,(GrColorTableP)(&cols)); /* GRX20 */
    cursorx=mousex;
    cursory=mousey;
    incr=8;
    emulation=1;
    GrMoveCursor(ecursor,cursorx,cursory);
  }
}

/* Shows cursor */

void cursor_on(void)
{
  if (!cursor_active) {
    if (emulation) GrDisplayCursor(ecursor);
    else GrMouseDisplayCursor();
    cursor_active=1;
  }
}

/* Hides cursor */

void cursor_off(void)
{
  if (cursor_active) {
    if (emulation) GrEraseCursor(ecursor);
    else GrMouseEraseCursor();
    cursor_active=0;
  }
}

/* Moves cursor */

void mouse_move(int x,int y)
{
int had_cursor;

  had_cursor=cursor_active;
  if (cursor_active) cursor_off();
  if (x>=GrScreenX()) x=GrScreenX()-1;
  if (x<0) x=0;
  if (y>=GrScreenY()) y=GrScreenY()-1;
  if (y<0) y=0;
  mousex=cursorx=x;
  mousey=cursory=y;
  if (emulation) GrMoveCursor(ecursor,x,y);
  else GrMouseWarp(x,y);
  if (had_cursor) cursor_on();
}

int xkbhit(void) /* returns the scan code and the key code */
{
  regs.x.ax=0x0100;
  INT16;
  return ((regs.x.flags & 0x0040)==0);
}

/* Reads the mouse current position and buttons */

void mouse_read(void)
{
  if (emulation) {
    if (!EmulacaoAtiva()) return;
    if (!Shift()) mouseb=0;
    if (key_pending) {
       regs.x.ax=0;
       INT16;
    }
    key_pending=0;
    if (xkbhit()) {
      switch (regs.x.ax >> 8) {
        case 0x4B:mouse_move(cursorx-incr,cursory); break;
        case 0x4D:mouse_move(cursorx+incr,cursory); break;
        case 0x48:mouse_move(cursorx,cursory-incr); break;
        case 0x50:mouse_move(cursorx,cursory+incr); break;
        case 0x47:incr=1; break;
        case 0x49:incr=32; break;
        case 0x51:incr=8; break;
        case 0x1C:mouseb=mouseb ^ 1; break;
        case 0x01:mouseb=mouseb ^ 4; break;
        case 0x39:mouseb=mouseb ^ 2; break;
        default:key_pending=1;
      }
      if (!key_pending) {
        regs.x.ax=0;
        INT16;
      }
    }
  }
  else {
    GrMouseGetEvent((GR_M_POLL | GR_M_EVENT | GR_M_NOPAINT),&mevent);
    mousex=mevent.x;
    mousey=mevent.y;
    mouseb=mevent.buttons;
    evkeyb=mevent.key;
    if (evkeyb>256) evkeyb+=(2000-256);
  }
}

int mkbhit(void)
{
int temp;
  if (emulation && cursor_active && EmulacaoAtiva()) temp=key_pending;
  else temp=kbhit();
  key_pending=0;
  return temp;
}
